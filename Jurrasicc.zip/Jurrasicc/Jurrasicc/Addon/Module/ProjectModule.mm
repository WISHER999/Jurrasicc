//
//  ProjectModule.m
//  CodeaProject
//
//  Created by Simeon Saint-Saens on 17/3/19.
//  Copyright © 2019 Two Lives Left. All rights reserved.
//

#import "ProjectModule.h"

@implementation ProjectModule
    
- (void)registerForAddon:(ProjectAddon *)addon {
    
}

@end
