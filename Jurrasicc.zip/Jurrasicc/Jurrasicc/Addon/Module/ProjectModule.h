//
//  ProjectModule.h
//  CodeaProject
//
//  Created by Simeon Saint-Saens on 17/3/19.
//  Copyright © 2019 Two Lives Left. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Module.h"

NS_ASSUME_NONNULL_BEGIN

@interface ProjectModule : NSObject<Module>

@end

NS_ASSUME_NONNULL_END
