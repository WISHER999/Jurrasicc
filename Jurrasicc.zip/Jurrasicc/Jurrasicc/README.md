#  Exported Codea Project

You've exported your project from Codea! Now what?

1. The first thing to do is select the *Download Frameworks* target from the drop-down menu in the Xcode toolbar. Then select **Product -> Build** or press **⌘B**
2. Then select your project from the same drop down menu, as well as the device or simulator you'd like to run it on
3. Then press play



